clear; clc;

#Sistema de ecuaciones diferenciales
# x1'' = (-k1*x1)/m1 + (k2*(x2-x1))/m1
# x2'' = (-k2(x2-x1))/m2

#Sustituciones
# y1 = x1
# y2 = x2
# y3 = x1'
# y4 = x2'
# y5 = x1''
# y6 = x2''

#Nuevo sistema de ecuaciones
# y1' = y3
# y2' = y4
# y3' = (-k1*x1)/m1 + (k2*(x2-x1))/m1
# y4' = (-k2(x2-x1))/m2


m1 = 1;
m2 = 3;
k1 = 3;
k2 = 4;


F = @(t,Y)  [
              Y(3);
              Y(4);
          ( (-k1*Y(1))/m1 + (k2*(Y(2)-Y(1)))/m1 );
          ( (-k2*(Y(2)-Y(1)))/m2);
             ];
              
yc = [0 0 1 1]';     

a = 0;
b = 30;

L = 60;       % 0.8865349811034779
L = 300;      % 0.839555597919226
h = (b-a)/L;
h = 0.1; % 0.839555597919226
h = h/2; % 0.839768617000917
h = h/2; % 0.839783699510593
%h = h/2; % 1.490273503865354
%h = h/2; % 1.490273490634971
%h = h/2;
L = (b-a)/h;

[t Y] = RK4(F,a,b,L,yc);

i_20 = 20/h +1;
t_20 = t(i_20);
x1_20 = Y(2,i_20);
dx1_20 = Y(4,i_20);
              
figure(1)
hold on;
grid on;              
plot(t,Y(1,:),'r-');
plot(t,Y(2,:),'b-');





