clc;clear;clf;

format long;
# Referido al ejercicio 9 de la GTP 5;
# Aqui comienza el ejercicio 9

x = 0:6;
y = [432 599 1012 1909 2977 4190 5961];

X = linspace(0, 12);

#a) pol grado 6
p6 = polyfit(x,y,6);
f6 = polyval(p6,X);
#b) pol grado 1
p1 = polyfit(x,y,1);
f1 = polyval(p1,X);
#c) pol grado 2
p2 = polyfit(x,y,2);
f2 = polyval(p2,X);

#d) graficar los tres modelos y ver error cuadratico
figure(1) 
grid on;
hold on;
plot(X,f1, "r-");
plot(X,f2, "g-");
%plot(X,f6, "b-");
leyendas = ["Grado 1"; "Grado 2"; "Grado 6"];
legend(leyendas);

%error cuadratico

#e) Predecir a las 10 semanas con los tres modelos
diezS1 = polyval(p1,10);
diezS2 = polyval(p2,10);
diezS6 = polyval(p6,10);

#f) error relativo cada modelo para las diez semanas sabiendo que f(10) = 14900
diezSreal = 14900;
err1 = abs((diezS1 - diezSreal)/diezSreal);
err2 = abs((diezS2 - diezSreal)/diezSreal);
err6 = abs((diezS6 - diezSreal)/diezSreal);
#Fin ejercicio 9

# Pregunta 1 parcial 2

p3 = polyfit(x,y,3);
p4 = polyfit(x,y,4); % polinomio de grado 4
f4 = @(x) polyval(p4,x);
plot(X,f4(X), "k-");
diezS4 = polyval(p4,10);

err4 = abs((diezS4 - diezSreal)/diezSreal);

err_cuadratico = 0;
for i = 1:7
  err_cuadratico += polyval(p6,x(i));
endfor

err_cuadratico = err_cuadratico / 7;








