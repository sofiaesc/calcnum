clear; clc;
format long;

# Referido al ejercicio 6 de la GTP 8;
# Aqui comienza el ejercicio 6


#Datos
a = 0;
b = 5;

K = 0.9;
u0 = 6;
H = 15;
ue = 4;

#Ecuacion diferencial
# -0.9u'' + (1.05x + 2)u' = 5x(5-x) -> Como lo estaba poniendo
# -0.9u'' + (1.05x + 2)u = 5x(5-x) -> Como tendria que haberlo puesto

#Reordenando
# u'' = (1/0.9)(1.05x + 2)u' - (5/0.9)x(5-x)

#Condiciones de contorno
# u(0) = 6
# 0.9u'(5) + 15u = 4

#Coeficiente de reaccion
%cr = @(x) 1.05.*x + 2;
%cr = @(x) 0.5.*x + 0.5; % cr utilizado en pregunta 5 del parcial 2
cr = @(x) 0.01.*x.^3 + 0.5; % cr para recup parcial 2

p = @(x) 0*x;                 % Termino con u'
q = @(x) (cr(x))./(K);        % Termino con u
r = @(x) (5.*x.*(5-x))./(-K); %  Fuente de calor

f = @(x) [p(x) q(x) r(x)];

# -K*duL = H*uL-H*ue) -> K*duL + H*uL +  = H*ue

rob = [K H H*ue];

h = 0.1;
h = h/2; % h = 0.05
h = h/2; % h = 0.025
%h = h/2; % h = 0.0125
%h = h/2; % h = 0.00625
%h = h/2; % h = 0.003125

# por lo menos h = 0.00625 para 4 digitos decimales exactos


L = (b-a)/h;

[x y A_aux A] = dif_fin_rob(f,a,b,u0,rob,L);

# Temperatura en el punto medio de la barra
i_medio = floor(length(x)/2) + 1; % Posicion del punto medio
x_medio = x(i_medio);             % Punto medio
y_medio = y(i_medio);             % Temperatura del punto medio
% 51.8168




#Fin ejercicio 6

# Pregunta 5 parcial 2 ( (1)cambios en el propio ejercicio)

# (2)

[c1 c2 c3 c4] = cubic_spline_natural(x',y');
M = [c4' c3' c2' c1'];
S = crear_spline(M,x);

figure(1)
hold on;
grid on;
plot(x,y,'r-');
%plot(x,S(x));

dy_a = aprox_dx_2PP(S,a,-4,-4);
flujo = dy_a*(-K);


flujo_b = H*(y(end) - ue);












