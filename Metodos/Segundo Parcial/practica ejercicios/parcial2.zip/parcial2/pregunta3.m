clear;clc;

# Referido al ejercicio 10 de la GTP 6;
# Aqui comienza el ejercicio 10

pol = [-1/5 0 0 20];
fpol = @(x) polyval(pol,x);
dfpol = @(x) polyval(polyder(pol),x);
f = @(x) 2*pi.*fpol(x).*sqrt(1+dfpol(x).^2);

a = 0;
b = 2;
L = 1;
L2 = 5;
n = 3;

Iexacta = quad(f,a,b);

IGauss = quad_gauss_c(f,a,b,L,n);
Isimp1 = intNCcompuesta(f,a,b,L,3);
Itrap5 = intNCcompuesta(f,a,b,L2,2);
Isimp5 = intNCcompuesta(f,a,b,L2,3);

#Ordenados por precision:
# Simpson 5 interv > Gauss 3 ptos > trapecio 5 interv > Simpson 3 interv

#Fin ejercicio 10

# Pregunta 3 parcial 2


func  = @(x) 2 + cos(pi.*x);
dfunc = @(x) pi.*cos(pi.*x);
f = @(x) 2*pi.*func(x).*sqrt(1+dfunc(x).^2);

L3 = 40;

IGauss_pregunta3 = quad_gauss_c(f,a,b,L3,n); % n = 3, a = 0, b = 2
%Restultado -> 57.92827084201713

#Buscando la cantidad de cifras exactas
L_extra = 200;
IGauss_pregunta3_extra = quad_gauss_c(f,a,b,L_extra,n);

