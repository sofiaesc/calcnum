clear; clc;

f = @(x) 5./x;

x = [1 2 3];
y = f(x);

[a b c d] = cubic_spline_natural(x,y);



